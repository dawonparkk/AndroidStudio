package com.example.currentplacedetailsonmap;

public class marker {
}
