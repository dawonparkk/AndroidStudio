package com.example.mapwithmarker;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * An activity that displays a Google map with a marker (pin) to indicate a particular location.
 */
public class MapsMarkerActivity extends AppCompatActivity
        implements OnMapReadyCallback {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve the content view that renders the map.
        setContentView(R.layout.activity_maps);
        // Get the SupportMapFragment and request notification
        // when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map when it's available.
     * The API invokes this callback when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user receives a prompt to install
     * Play services inside the SupportMapFragment. The API invokes this method after the user has
     * installed Google Play services and returned to the app.
     */


    @Override
    public void onMapReady(GoogleMap googleMap) {
        // 구글 맵 객체를 불러온다.


        double f = (double)1/100;

        // for loop를 통한 n개의 마커 생성
        for ( double idx = 0; idx < 0.02 ; idx=idx+f) {
            // 1. 마커 옵션 설정 (만드는 과정)
            MarkerOptions makerOptions = new MarkerOptions();
            makerOptions // LatLng에 대한 어레이를 만들어서 이용할 수도 있다.
                    .position(new LatLng(37.504726 + idx, 127.065242))
                    .title("마커" + idx); // 타이틀.

            // 2. 마커 생성 (마커를 나타냄)
            LatLng location = new LatLng(37.504726, 127.065242);
            googleMap.addMarker(makerOptions);
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 14));
        }

        // 카메라를 위치로 옮긴다.
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(37.504726, 127.065242)));
    }
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        // Add a marker in Sydney, Australia,
//        // and move the map's camera to the same location.
//        LatLng seoul = new LatLng(37.505880, 127.064896);
//        googleMap.addMarker(new MarkerOptions().position(seoul)
//                .title("Marker in g"));
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(seoul));
//    }
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        // Add a marker in seoul, Australia,
//        // and move the map's camera to the same location.
//        LatLng seoul= new LatLng(37.505838, 127.062105);
//        googleMap.addMarker(new MarkerOptions().position(seoul)
//                .title("Marker in g"));
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(seoul));
//    }
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        // Add a marker in Sydney, Australia,
//        // and move the map's camera to the same location.
//        LatLng sydney = new LatLng(37.506953, 127.062051);
//        googleMap.addMarker(new MarkerOptions().position(sydney)
//                .title("Marker in g"));
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
//    }
}
